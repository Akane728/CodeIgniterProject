<?php

namespace App\Models;

use CodeIgniter\Model;

class AdminModel extends Model
{
    protected $table = 'admin';

    public function authenticate($username, $password)
    {
        $admin = $this->where('username', $username)->first();

        if ($admin && $password === $admin['password']) {
            return $admin;
        }

        return false;
    }
}
