<?php

namespace App\Controllers;

use App\Models\AdminModel;
use CodeIgniter\Controller;

class Admin extends BaseController
{
    public function index()
    {
        return view('adminlogin');
    }

    public function login()
    {
        $session = session();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $model = new AdminModel();

        $admin = $model->authenticate($username, $password);

        if ($admin) {
            $session->set('isLoggedIn', true);
            return redirect()->to('students');
        } else {
            return redirect()->to('/')->with('error', 'Invalid username or password.');
        }
    }
}
