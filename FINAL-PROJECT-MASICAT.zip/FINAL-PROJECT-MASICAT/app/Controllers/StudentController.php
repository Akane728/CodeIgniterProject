<?php

namespace App\Controllers;

use App\Models\StudentModel;
use CodeIgniter\Controller;

class StudentController extends Controller
{
    public function index()
    {
        $model = new StudentModel();
        $data['students'] = $model->findAll();
        
        return view('studentsindex', $data);
    }

    public function add()
    {
        return view('students/add');
    }

    public function save()
    {
        $model = new StudentModel();
        
        $data = [
            'first_name' => $this->request->getPost('first_name'),
            'last_name' => $this->request->getPost('last_name'),
            'email' => $this->request->getPost('email'),
        ];
        
        $model->insert($data);
        
        return redirect()->to('students');
    }

    public function update()
    {
        $model = new StudentModel();
        
        $id = $this->request->getPost('student_id');
        $data = [
            'first_name' => $this->request->getPost('first_name'),
            'last_name' => $this->request->getPost('last_name'),
            'email' => $this->request->getPost('email'),
        ];
        
        $model->update($id, $data);
        
        return redirect()->to('students');
    }

    public function delete($student_id)
    {
        $model = new StudentModel();
        $model->delete($student_id);

        return redirect()->to('students');
    }
}
