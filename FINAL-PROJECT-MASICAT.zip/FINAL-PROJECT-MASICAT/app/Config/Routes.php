<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Admin::index');
$routes->post('admin/login', 'Admin::login');

$routes->get('students', 'StudentController::index');
$routes->post('students/save', 'StudentController::save');
$routes->post('students/update', 'StudentController::update');
$routes->get('students/delete/(:num)', 'StudentController::delete/$1');

